package modele;

public record Medicament ( int id_med, String nom_med, String description, int stock){

}
