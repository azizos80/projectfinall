package modele;

public record Ordo (Medicament medicament,Client cli) {}
