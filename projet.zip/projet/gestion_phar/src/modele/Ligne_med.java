package modele;

public record Ligne_med (double qte,Medicament medicament,Ordo ordo) {

}
