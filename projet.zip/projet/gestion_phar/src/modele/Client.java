package modele;

public record Client ( int id_cl, String nom_cli  ,String prenom, double credit,String adresse,String num_tel) {}


