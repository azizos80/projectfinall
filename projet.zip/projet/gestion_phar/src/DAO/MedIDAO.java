package DAO;

import javax.swing.*;

import modele.Medicament;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;



public class MedIDAO implements IDAO<Medicament> {
	private final String url = "jdbc:mysql://localhost:3306/projet";
    private final String user = "root";
    private final String password = "14072004336";

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }

    @Override
    public void ajouter(Medicament m) {
        try (Connection con = getConnection() ;
             PreparedStatement ps = con.prepareStatement("INSERT INTO medicament(nom_med, stock) VALUES (?, ?)")) {

            ps.setString(1, m.nom_med());
            ps.setInt(2, m.stock());
            ps.executeUpdate();
            

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erreur insertion : " + e.getMessage());
      
        }
    }

    @Override
    public void modifier(Medicament m) {
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement("UPDATE medicament SET nom_med=?, stock=? WHERE id_med=?")) {

            ps.setString(1, m.nom_med());
            ps.setInt(2, m.stock());
            ps.setInt(3, m.id_med());
            ps.executeUpdate();
            

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erreur modification : " + e.getMessage());
          
        }
    }

    @Override
    public void supprimer(int id) {
        try (Connection con =getConnection();
             PreparedStatement ps = con.prepareStatement("DELETE FROM medicament WHERE id_med=?")) {

            ps.setInt(1, id);
            ps.executeUpdate();
           

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erreur suppression : " + e.getMessage());
           
        }
    }

    @Override
    public List<Medicament> lister() {
        List<Medicament> liste = new ArrayList<>();
        try (Connection con = getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM medicament")) {

            while (rs.next()) {
                liste.add(new Medicament(
                        rs.getInt("id_med"),
                        rs.getString("nom_med"),
                        rs.getString("description"),
                        rs.getInt("stock")
                ));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erreur chargement : " + e.getMessage());
        }
        return liste;
    }


    @Override
    public void enregistrer(Medicament m) {
        if (m.id_med() == -1) {
            ajouter(m);
        } else {
            modifier(m);
        }
    }

	@Override
	public void fermer(JFrame frame) {
        frame.dispose(); // Ferme la fenêtre passée en paramètre
    }
}
		

