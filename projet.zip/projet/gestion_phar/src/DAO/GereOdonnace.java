package DAO;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class GereOdonnace {

    private Connection con;

    public GereOdonnace() {
        try {
            String url = "jdbc:mysql://localhost:3306/projet";
            String user = "root";
            String pass = "14072004336";
            con = DriverManager.getConnection(url, user, pass);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erreur de connexion à la base de données !");
        }
    }

    

        public String ajouterOrdonnance(int idOrd, int idMed, int quantite, String description) {
            try {
                String queryStock = "SELECT stock FROM medicament WHERE id_med = ?";
                PreparedStatement psStock = con.prepareStatement(queryStock);
                psStock.setInt(1, idMed);
                ResultSet rsStock = psStock.executeQuery();

                if (rsStock.next()) {
                    int currentStock = rsStock.getInt("stock");

                    if (currentStock >= quantite) {
                        // Insert dans ordonnance
                        String queryAddOrdonnance = "INSERT INTO ordonnance (id_ord, discription) VALUES (?, ?)";
                        PreparedStatement psAdd = con.prepareStatement(queryAddOrdonnance);
                        psAdd.setInt(1, idOrd);
                        psAdd.setString(2, description);
                        psAdd.executeUpdate();

                        // Insert dans ligne_med
                        String queryLigne = "INSERT INTO ligne_med (id_ord, id_med, quantite) VALUES (?, ?, ?)";
                        PreparedStatement psLigne = con.prepareStatement(queryLigne);
                        psLigne.setInt(1, idOrd);
                        psLigne.setInt(2, idMed);
                        psLigne.setInt(3, quantite);
                        psLigne.executeUpdate();

                        // Mise à jour du stock
                        String queryUpdateStock = "UPDATE medicament SET stock = stock - ? WHERE id_med = ?";
                        PreparedStatement psUpdateStock = con.prepareStatement(queryUpdateStock);
                        psUpdateStock.setInt(1, quantite);
                        psUpdateStock.setInt(2, idMed);
                        psUpdateStock.executeUpdate();

                        return "Ordonnance ajoutée avec succès.";
                    } else {
                        return "Stock insuffisant.";
                    }
                } else {
                    return "Médicament non trouvé.";
                }
            } catch (SQLException e) {
                e.printStackTrace();
                return "Erreur lors de l'ajout.";
            }
        }

        public void supprimerOrdonnance(int idOrd) {
            try {
                String sql = "DELETE FROM ordonnance WHERE id_ord = ?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setInt(1, idOrd);
                ps.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        public void enregistrerOrdonnance(int idOrd, String description) {
            try {
                String sql = "UPDATE ordonnance SET discription = ? WHERE id_ord = ?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, description);
                ps.setInt(2, idOrd);
                ps.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    


    public void fermer(JFrame frame) {
        if (frame != null) {
            frame.dispose();
        }
    }
}
