package DAO;

import java.sql.*;
import java.util.*;
import modele.Client;

public class ClientIDAOGETT implements IDAOGETALL<Client> {

    @Override
    public List<Client> getAll() throws SQLException {
        List<Client> clients = new ArrayList<>();
        Connection cx = SingletonConnection.getInstance();
        PreparedStatement ps = cx.prepareStatement("SELECT * FROM client");
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            Client client = new Client(
                rs.getInt("id_cl"),     
                rs.getString("nom_cli"), 
                rs.getString("prenom"),  
                rs.getDouble("credit"), 
                rs.getString("adresse"), 
                rs.getString("num_tel")   
            );
            clients.add(client);
        }
 
        rs.close();
        ps.close();
        
        return clients;
    }
}
