package DAO;

import java.sql.SQLException;


import java.util.List;

import javax.swing.JFrame;

public interface IDAO<T> {
    void ajouter(T obj);
    void modifier(T obj);
    void supprimer(int obj) throws SQLException;
    void enregistrer(T obj);
    void fermer(JFrame frame);
    List<T> lister();
}

