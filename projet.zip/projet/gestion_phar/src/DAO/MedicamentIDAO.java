package DAO;

import java.sql.*;
import java.util.*;
import modele.Medicament;

public class MedicamentIDAO implements IDAOGETALL<Medicament> {

    @Override
    public List<Medicament> getAll() throws SQLException {
        List<Medicament> medicaments = new ArrayList<>();
        Connection cx = SingletonConnection.getInstance();
        PreparedStatement ps = cx.prepareStatement("SELECT * FROM medicament");
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            Medicament medicament = new Medicament(
                rs.getInt("id_med"),        
                rs.getString("nom_med"),    
                rs.getString("description"), 
                rs.getInt("stock")          
            );

            medicaments.add(medicament);
        }
        rs.close();
        ps.close();
        
        return medicaments;
    }
    public List<Medicament> rechercher(String nom) throws SQLException {
        List<Medicament> result = new ArrayList<>();
        Connection cx = SingletonConnection.getInstance();
        String sql = "SELECT * FROM medicament WHERE nom_med LIKE ?";
        PreparedStatement ps = cx.prepareStatement(sql);
        ps.setString(1, "%" + nom + "%");
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Medicament medicament = new Medicament(
                rs.getInt("id_med"),
                rs.getString("nom_med"),
                rs.getString("description"),
                rs.getInt("stock")
            );
            result.add(medicament);
        }
        rs.close();
        ps.close();
        
        return result;
    }

}
