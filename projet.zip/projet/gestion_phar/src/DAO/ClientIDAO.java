package DAO;

import modele.Client;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClientIDAO implements IDAO<Client> {

    private Connection con;

    public ClientIDAO() {
        try {
            String url = "jdbc:mysql://localhost:3306/projet";
            String user = "root";
            String pass = "14072004336";
            con = DriverManager.getConnection(url, user, pass);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erreur de connexion à la base de données !");
        }
    }

    @Override
    public void ajouter(Client client) {
        String sql = "INSERT INTO client (nom_cli, prenom, credit, adresse, num_tel) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, client.nom_cli());
            ps.setString(2, client.prenom());
            ps.setDouble(3, client.credit());
            ps.setString(4, client.adresse());
            ps.setString(5, client.num_tel());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void modifier(Client client) {
        String sql = "UPDATE client SET nom_cli = ?, prenom = ?, credit = ?, adresse = ?, num_tel = ? WHERE id_cl = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, client.nom_cli());
            ps.setString(2, client.prenom());
            ps.setDouble(3, client.credit());
            ps.setString(4, client.adresse());
            ps.setString(5, client.num_tel());
            ps.setInt(6, client.id_cl());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void supprimer(int id) throws SQLException {
        String sql = "DELETE FROM client WHERE id_cl = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    @Override
    public void enregistrer(Client client) {
        modifier(client);
    }

    @Override
    public void fermer(JFrame frame) {
        frame.dispose();
    }

    @Override
    public List<Client> lister() {
        List<Client> clients = new ArrayList<>();
        String sql = "SELECT * FROM client";
        try (Statement stmt = con.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                clients.add(new Client(
                        rs.getInt("id_cl"),
                        rs.getString("nom_cli"),
                        rs.getString("prenom"),
                        rs.getDouble("credit"),
                        rs.getString("adresse"),
                        rs.getString("num_tel")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return clients;
    }
}
