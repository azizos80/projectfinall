package gestion_phar;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class GereOrdonnance extends JFrame {

    private JTextField txtIdOrd, txtDescription, txtIdMed, txtQuantite;
    private JButton btnAjouter, btnSupprimer, btnEnregistrer, btnFermer;
    private JTable table;
    private DefaultTableModel tableModel;
    private Connection connection;

    public GereOrdonnance() {
        setSize(843, 774);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(189, 215, 199));

        // Images et autres éléments visuels
        ImageIcon icon1 = new ImageIcon("C:\\Users\\jammo\\Downloads\\err.png");
        Image image1 = icon1.getImage().getScaledInstance(250, 250, Image.SCALE_SMOOTH);
        ImageIcon icon2 = new ImageIcon("C:\\Users\\jammo\\Downloads\\cds.png");
        Image image2 = icon2.getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH);
        JLabel imgLabel1 = new JLabel(new ImageIcon(image1));
        JLabel imgLabel2 = new JLabel(new ImageIcon(image2));
        imgLabel1.setHorizontalAlignment(JLabel.CENTER);
        imgLabel2.setHorizontalAlignment(JLabel.RIGHT);

        // Panel image
        JPanel imgPanel2 = new JPanel();
        imgPanel2.setOpaque(false);
        GroupLayout gl_imgPanel2 = new GroupLayout(imgPanel2);
        gl_imgPanel2.setHorizontalGroup(
            gl_imgPanel2.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(gl_imgPanel2.createSequentialGroup()
                    .addGap(50)
                    .addComponent(imgLabel1, GroupLayout.PREFERRED_SIZE, 525, GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(imgLabel2)
                    .addGap(48))
        );
        gl_imgPanel2.setVerticalGroup(
            gl_imgPanel2.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(imgLabel1)
                .addGroup(GroupLayout.Alignment.TRAILING, gl_imgPanel2.createSequentialGroup()
                    .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(imgLabel2, GroupLayout.PREFERRED_SIZE, 250, GroupLayout.PREFERRED_SIZE)
                    .addContainerGap())
        );
        imgPanel2.setLayout(gl_imgPanel2);

        // Panel avec coins arrondis
        JPanel roundedSquarePanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color squareColor = new Color(219, 231, 222, 180);
                g2d.setColor(squareColor);
                int width = 700;
                int height = 500;
                int arcSize = 100;
                int x = (getWidth() - width) / 2;
                int y = (getHeight() - height) / 2;
                g2d.fillRoundRect(x, y, width, height, arcSize, arcSize);
            }
        };
        roundedSquarePanel.setOpaque(false);

        // Configuration des champs et boutons
        JPanel contentPanel = new JPanel(new GridBagLayout());
        contentPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 15, 5, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblIdOrd = new JLabel("ID Ordonnance:");
        JLabel lblDescription = new JLabel("Description:");
        JLabel lblIdMed = new JLabel("ID Médicament:");
        JLabel lblQuantite = new JLabel("Quantité:");

        txtIdOrd = new JTextField(8);
        txtDescription = new JTextField();
        txtIdMed = new JTextField(5);
        txtQuantite = new JTextField(8);

        gbc.gridx = 0; gbc.gridy = 0;
        contentPanel.add(lblIdOrd, gbc);
        gbc.gridx = 1;
        contentPanel.add(txtIdOrd, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        contentPanel.add(lblDescription, gbc);
        gbc.gridx = 1;
        contentPanel.add(txtDescription, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        contentPanel.add(lblIdMed, gbc);
        gbc.gridx = 1;
        contentPanel.add(txtIdMed, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        contentPanel.add(lblQuantite, gbc);
        gbc.gridx = 1;
        contentPanel.add(txtQuantite, gbc);

        // Table pour afficher les ordonnances
        tableModel = new DefaultTableModel(new Object[]{"ID Ordonnance", "Description", "ID Médicament", "Nom Médicament", "Stock"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        table = new JTable(tableModel);
        table.setRowHeight(30);
        table.setFont(new Font("Arial", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        table.getTableHeader().setBackground(new Color(189, 215, 199));

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(650, 150));

        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        contentPanel.add(scrollPane, gbc);

        // Panel pour les boutons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        btnAjouter = new JButton("Ajouter");
        btnSupprimer = new JButton("Supprimer");
        btnEnregistrer = new JButton("Enregistrer");
        btnFermer = new JButton("Fermer");

        btnEnregistrer.setBackground(new Color(74, 124, 112));
        btnEnregistrer.setForeground(Color.WHITE);
        btnEnregistrer.setFocusPainted(false);
        btnEnregistrer.setFont(new Font("Arial", Font.BOLD, 14));

        buttonPanel.add(btnAjouter);
        buttonPanel.add(btnSupprimer);
        buttonPanel.add(btnEnregistrer);
        buttonPanel.add(btnFermer);
        buttonPanel.setOpaque(false);

        gbc.gridy = 5;
        contentPanel.add(buttonPanel, gbc);

        roundedSquarePanel.add(contentPanel, BorderLayout.CENTER);
        mainPanel.add(imgPanel2, BorderLayout.NORTH);
        mainPanel.add(roundedSquarePanel, BorderLayout.CENTER);
        mainPanel.add(Box.createVerticalStrut(20), BorderLayout.SOUTH);
        getContentPane().add(mainPanel);

        // Action sur bouton Fermer
        btnFermer.addActionListener(e -> dispose());

        // Connexion à la base de données
        connectDatabase();
        loadData();

        // Chargement des données dans la table lors du clic
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    txtIdOrd.setText(table.getValueAt(selectedRow, 0).toString());
                    txtDescription.setText(table.getValueAt(selectedRow, 1).toString());
                    txtIdMed.setText(table.getValueAt(selectedRow, 2).toString());
                }
            }
        });

        // Actions sur les boutons
        btnAjouter.addActionListener(e -> {
            try {
                int idOrd = Integer.parseInt(txtIdOrd.getText());
                int idMed = Integer.parseInt(txtIdMed.getText());
                int quantite = Integer.parseInt(txtQuantite.getText());

                // Ajouter l'ordonnance et mettre à jour le stock
                String result = ajouterOrdonnance(idOrd, idMed, quantite);

                // Afficher un message de résultat
                JOptionPane.showMessageDialog(null, result);

                // Recharger les données dans le tableau après l'ajout
                loadData();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Veuillez entrer des valeurs valides.");
            }
        });

        btnSupprimer.addActionListener(e -> {
            int idOrd = Integer.parseInt(txtIdOrd.getText());
            supprimerOrdonnance(idOrd);
        });

        btnEnregistrer.addActionListener(e -> {
            int idOrd = Integer.parseInt(txtIdOrd.getText());
            String description = txtDescription.getText();
            int idMed = Integer.parseInt(txtIdMed.getText());
            int quantite = Integer.parseInt(txtQuantite.getText());
            enregistrerOrdonnance(idOrd, description, idMed, quantite);
        });
    }

    private void connectDatabase() {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/projet", "root", "14072004336");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadData() {
        try {
            Statement stmt = connection.createStatement();
            String query = "SELECT o.id_ord, m.id_med, m.nom_med, m.stock, o.discription " +
                           "FROM ordonnance o " +
                           "JOIN medicament m ON o.discription LIKE CONCAT(m.nom_med, '%')";
            ResultSet rs = stmt.executeQuery(query);

            tableModel.setRowCount(0);
            while (rs.next()) {
                int idOrd = rs.getInt("id_ord");
                int idMed = rs.getInt("id_med");
                String nomMed = rs.getString("nom_med");
                int stock = rs.getInt("stock");
                String description = rs.getString("discription");
                tableModel.addRow(new Object[]{idOrd, description, idMed, nomMed, stock});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private String ajouterOrdonnance(int idOrd, int idMed, int quantite) {
        try {
            // Vérifier si le stock est suffisant
            String queryStock = "SELECT stock FROM medicament WHERE id_med = ?";
            PreparedStatement psStock = connection.prepareStatement(queryStock);
            psStock.setInt(1, idMed);
            ResultSet rsStock = psStock.executeQuery();

            if (rsStock.next()) {
                int currentStock = rsStock.getInt("stock");

                if (currentStock >= quantite) {
                    // Ajouter l'ordonnance
                    String queryAddOrdonnance = "INSERT INTO Ligne_med (id_ord, id_med, quantite) VALUES (?, ?, ?)";
                    PreparedStatement psAdd = connection.prepareStatement(queryAddOrdonnance);
                    psAdd.setInt(1, idOrd);
                    psAdd.setInt(2, idMed);
                    psAdd.setInt(3, quantite);
                    psAdd.executeUpdate();

                    // Mise à jour du stock
                    String queryUpdateStock = "UPDATE medicament SET stock = stock - ? WHERE id_med = ?";
                    PreparedStatement psUpdateStock = connection.prepareStatement(queryUpdateStock);
                    psUpdateStock.setInt(1, quantite);
                    psUpdateStock.setInt(2, idMed);
                    psUpdateStock.executeUpdate();

                    return "Ordonnance ajoutée et stock mis à jour.";
                } else {
                    return "Stock insuffisant pour cette ordonnance.";
                }
            } else {
                return "Médicament non trouvé.";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erreur lors de l'ajout de l'ordonnance.";
        }
    }

    private void supprimerOrdonnance(int idOrd) {
        try {
            String sql = "DELETE FROM ordonnance WHERE id_ord = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, idOrd);
            ps.executeUpdate();
            loadData();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void enregistrerOrdonnance(int idOrd, String description, int idMed, int quantite) {
        try {
            String sql = "UPDATE ordonnance SET discription = ?, id_med = ?, quantite = ? WHERE id_ord = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, description);
            ps.setInt(2, idMed);
            ps.setInt(3, quantite);
            ps.setInt(4, idOrd);
            ps.executeUpdate();
            loadData();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GereOrdonnance().setVisible(true));
    }
}