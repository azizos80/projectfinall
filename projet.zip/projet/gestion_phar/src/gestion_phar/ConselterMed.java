package gestion_phar;

import DAO.MedicamentIDAO;
import modele.Medicament;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.sql.*;
import java.util.List;

public class ConselterMed extends JFrame {
    private JTable table;
    private JTextField searchField;
    private JButton searchButton, showAllButton, backButton;
    private DefaultTableModel model;
    private Image backgroundImage;

    private static final String DB_URL = "jdbc:mysql://localhost:3306/projet";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "14072004336";

    public ConselterMed() {
        setTitle("Gestion des Médicaments");
        setSize(900, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

        try {
            ImageIcon bgIcon = new ImageIcon("C:/Users/jammo/Downloads/cb9ab3d9-224b-4d38-9ebe-da59242d89ea.png");
            backgroundImage = bgIcon.getImage();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Image de fond non trouvée", "Erreur", JOptionPane.ERROR_MESSAGE);
        }

        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        mainPanel.setOpaque(false);

        // En-tête
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setOpaque(false);

        try {
            ImageIcon icon = new ImageIcon("C:/Users/jammo/Downloads/stethoscope.png");
            Image scaledIcon = icon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
            JLabel iconLabel = new JLabel(new ImageIcon(scaledIcon));
            iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            headerPanel.add(iconLabel);
        } catch (Exception e) {
            System.err.println("Icône non trouvée: " + e.getMessage());
        }

        JLabel titleLabel = new JLabel("Médicaments");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(new Color(0, 100, 100));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        headerPanel.add(titleLabel);

        // Panneau de recherche avec fond violet clair
        JPanel searchPanelContainer = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        searchPanelContainer.setBackground(new Color(216, 216, 235)); // violet clair
        searchPanelContainer.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel searchLabel = new JLabel("Nom Médicament");
        searchLabel.setFont(new Font("Arial", Font.BOLD, 16));
        searchPanelContainer.add(searchLabel);

        searchField = new JTextField("Aspirine", 20);
        searchField.setFont(new Font("Arial", Font.PLAIN, 14));
        searchField.setBackground(Color.WHITE);
        searchPanelContainer.add(searchField);

        searchButton = createStyledButton("Rechercher", new Color(64, 64, 64)); // gris foncé
        searchPanelContainer.add(searchButton);

        headerPanel.add(Box.createVerticalStrut(10));
        headerPanel.add(searchPanelContainer);

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Tableau
        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        model.addColumn("ID");
        model.addColumn("NOM Med");
        model.addColumn("DESCRIPTION");
        model.addColumn("STOCK");

        table = new JTable(model);
        table.setFont(new Font("Arial", Font.PLAIN, 14));
        table.setRowHeight(25);
        table.setSelectionBackground(new Color(173, 216, 230));
        table.setSelectionForeground(Color.BLACK);
        table.setGridColor(new Color(200, 200, 200));
        table.setBackground(new Color(240, 240, 240));

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Arial", Font.BOLD, 14));
        header.setBackground(new Color(70, 130, 180)); // gris bleuté
        header.setForeground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(70, 130, 180), 2));

        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Boutons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 15));
        buttonPanel.setOpaque(false);

        showAllButton = createStyledButton("Afficher tous", new Color(102, 153, 139)); // vert doux
        backButton = createStyledButton("Retour", new Color(105, 105, 105)); // gris foncé

        buttonPanel.add(showAllButton);
        buttonPanel.add(backButton);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        setContentPane(mainPanel);

        // Données
        loadAllMedicaments();

        searchButton.addActionListener(e -> searchMedicament());
        showAllButton.addActionListener(e -> loadAllMedicaments());
        backButton.addActionListener(e -> {
            dispose();
            // new MenuPrincipal().setVisible(true); // si MenuPrincipal existe
        });
    }

    private JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor.darker());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });

        return button;
    }

    private void loadAllMedicaments() {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
            String query = "SELECT * FROM medicament ORDER BY nom_med";
            PreparedStatement pst = conn.prepareStatement(query);
            ResultSet rs = pst.executeQuery();

            model.setRowCount(0);

            while (rs.next()) {
                model.addRow(new Object[] {
                    rs.getInt("id_med"),
                    rs.getString("nom_med"),
                    rs.getString("description"),
                    rs.getInt("stock")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erreur lors du chargement des médicaments: " + ex.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void searchMedicament() {
        String searchTerm = searchField.getText().trim();

        if (searchTerm.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez entrer un nom de médicament.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        model.setRowCount(0);

        MedicamentIDAO dao = new MedicamentIDAO();
        try {
            List<Medicament> list = dao.rechercher(searchTerm);

            for (Medicament m : list) {
                model.addRow(new Object[] {
                    m.id_med(),
                    m.nom_med(),
                    m.description(),
                    m.stock()
                });
            }

            if (list.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Aucun médicament trouvé pour: " + searchTerm, "Résultat vide", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erreur lors de la recherche: " + e.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Driver JDBC non trouvé: " + e.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
            return;
        }

        SwingUtilities.invokeLater(() -> {
            ConselterMed app = new ConselterMed();
            app.setVisible(true);
        });
    }
}
