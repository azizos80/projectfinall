
package gestion_phar;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class PharmacyClientList extends JFrame {
    private JTable table;
    private DefaultTableModel model;

    public PharmacyClientList() {
        setTitle("Liste des Clients - Pharmacie");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{"ID", "Nom", "Prénom", "Crédit", "Adresse", "Numéro de Téléphone"});
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        add(scrollPane, BorderLayout.CENTER);

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmacie", "root", "");
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT id, nom_cli, prenom, credit, adresse, num_tel FROM clients");

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("nom_cli"),
                    rs.getString("prenom"),
                    rs.getDouble("credit"),
                    rs.getString("adresse"),
                    rs.getString("num_tel")
                });
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erreur de connexion à la base de données.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PharmacyClientList().setVisible(true));
    }
}
