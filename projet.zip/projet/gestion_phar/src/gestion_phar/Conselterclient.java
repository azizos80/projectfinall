package gestion_phar;

import DAO.ClientIDAOGETT;
import modele.Client;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.util.List;

public class Conselterclient extends JFrame {
    private JTable table;
    private DefaultTableModel model;

    public Conselterclient() {
        setTitle("Gestion des Clients - Pharmacie");
        setSize(760, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

        Color softGreen = new Color(221, 245, 209);
        Color darkGreen = new Color(0, 100, 0);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(softGreen);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.BLACK);
        headerPanel.setPreferredSize(new Dimension(760, 220));

        try {
            ImageIcon originalIcon = new ImageIcon("C:\\Users\\jammo\\Downloads\\ChatGPT Image May 7, 2025, 02_28_02 PM.png");
            Image scaledImage = originalIcon.getImage().getScaledInstance(740, 220, Image.SCALE_SMOOTH);
            JLabel imageLabel = new JLabel(new ImageIcon(scaledImage));
            imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
            headerPanel.add(imageLabel, BorderLayout.CENTER);
        } catch (Exception e) {
            JLabel placeholder = new JLabel("PHARMACIE");
            placeholder.setFont(new Font("Arial", Font.BOLD, 24));
            placeholder.setHorizontalAlignment(SwingConstants.CENTER);
            headerPanel.add(placeholder, BorderLayout.CENTER);
        }

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        model = new DefaultTableModel() {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        model.setColumnIdentifiers(new String[]{"ID", "Nom", "Prénom", "Crédit", "Adresse", "Téléphone"});

        table = new JTable(model);
        table.setRowHeight(26);
        table.setFont(new Font("Arial", Font.PLAIN, 14));
        table.setGridColor(darkGreen);
        table.setBorder(BorderFactory.createLineBorder(darkGreen, 2));

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Arial", Font.BOLD, 16));
        header.setBackground(softGreen);
        header.setForeground(darkGreen);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        for (int i = 0; i < model.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(darkGreen, 2));
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        JButton retourButton = new JButton(" Retour");
        retourButton.setFont(new Font("Arial", Font.BOLD, 16));
        retourButton.setBackground(new Color(34, 139, 87));
        retourButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        retourButton.setFocusPainted(false);
        retourButton.setPreferredSize(new Dimension(140, 45));
        retourButton.setBorder(BorderFactory.createLineBorder(new Color(0, 90, 60), 2));

        retourButton.addActionListener(e -> dispose());

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(softGreen);
        buttonPanel.add(retourButton);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Chargement des données
        chargerClients();

        setContentPane(mainPanel);
    }

    private void chargerClients() {
        try {
            ClientIDAOGETT dao = new ClientIDAOGETT();
            List<Client> clients = dao.getAll();
            model.setRowCount(0);

            for (Client c : clients) {
                model.addRow(new Object[]{
                        c.id_cl(),
                        c.nom_cli(),
                        c.prenom(),
                        String.format("%.2f", c.credit()),
                        c.adresse(),
                        c.num_tel()
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erreur lors du chargement des clients : " + e.getMessage(),
                    "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new Conselterclient().setVisible(true);
        });
    }
}
