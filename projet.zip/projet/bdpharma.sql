use projet;
CREATE TABLE utilisateur (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nom_uti VARCHAR(50),
    mot_de_passe INT,
    typee VARCHAR(50)
);
CREATE TABLE client (
    id_cl INT PRIMARY KEY AUTO_INCREMENT,
    nom_cli VARCHAR(20),
    prenom VARCHAR(20),
    adresse varchar(20),
    num_tel varchar(20),
    credit DOUBLE
);
CREATE TABLE medicament (
    id_med INT PRIMARY KEY AUTO_INCREMENT,
    nom_med VARCHAR(20) NOT NULL UNIQUE,
    stock INT NOT NULL DEFAULT 0 CHECK (stock >= 0),
    description VARCHAR(255)
);
CREATE TABLE ordonnance (
    id_ord INT PRIMARY KEY AUTO_INCREMENT,
    discription VARCHAR(50)
);
CREATE TABLE ligne_med (
    id_ord INT,
    id_med INT,
    quantite INT CHECK (quantite > 0),
    PRIMARY KEY (id_ord, id_med),
    FOREIGN KEY (id_ord) REFERENCES ordonnance(id_ord),
    FOREIGN KEY (id_med) REFERENCES medicament(id_med)
);

INSERT INTO utilisateur (nom_uti, mot_de_passe, typee) VALUES 
('Alice', 1234, 'administrateur'),
('Bob', 5678, 'pharmacien'),
('Charlie', 9012, 'pharmacien'),
('Diane', 3456, 'administrateur');
INSERT INTO client (nom_cli, prenom, credit, adresse, num_tel) VALUES
('Benali', 'Sami', 1500.75, 'Sousse', '20 123 456'),
('Khelifa', 'Yasmine', 2200.00, 'Sfax', '29 987 654'),
('Mansour', 'Ali', 500.50, 'Tunis', '21 456 789'),
('Zahraoui', 'Lina', 3200.20, 'Nabeul', '27 321 789');
INSERT INTO medicament (nom_med, stock, description) VALUES
('Paracétamol', 48, 'Pour soulager la douleur et la fièvre'),
('Ibuprofène', 48, 'Anti-inflammatoire non stéroïdien'),
('Aspirine', 35, 'Anti-inflammatoire et antiagrégant plaquettaire'),
('Amoxicilline', 12, 'Antibiotique de la famille des pénicillines'),
('Oméprazole', 59, 'Inhibiteur de la pompe à protons'),
('Cétirizine', 30, 'Antihistaminique pour allergies'),
('Tramadol', 12, 'Antalgique opiacé'),
('Atorvastatine', 19, 'Hypolipémiant de la classe des statines'),
('Insuline', 150, 'Hormone pour le traitement du diabète'),
('Metformine', 87, 'Antidiabétique oral de la classe des biguanides');

INSERT INTO ordonnance (discription) VALUES
('Paracétamol : traitement pour la fièvre'),
('Ibuprofène : soulagement des douleurs'),
('Aspirine : fluidification du sang'),
('Amoxicilline : antibiotique contre infections'),
('Oméprazole : pour les brûlures d’estomac'),
('Cétirizine : traitement des allergies'),
('Tramadol : antidouleur puissant'),
('Atorvastatine : régulation du cholestérol'),
('Insuline : pour le diabète'),
('Metformine : antidiabétique oral');



INSERT INTO ligne_med (id_ord, id_med, quantite) VALUES
(1, 1, 2),
(2, 4, 1),
(3, 2, 3),
(4, 9, 2);
SELECT 
    o.id_ord,
    m.id_med,
    m.nom_med,
    o.discription
FROM 
    ordonnance o
JOIN 
    medicament m 
ON 
    o.discription LIKE CONCAT(m.nom_med, '%');

SELECT id_ord, discription FROM ordonnance;



SELECT * FROM ordonnance;